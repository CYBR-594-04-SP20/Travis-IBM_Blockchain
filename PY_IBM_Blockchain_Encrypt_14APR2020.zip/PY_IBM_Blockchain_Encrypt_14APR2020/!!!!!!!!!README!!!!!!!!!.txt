Script was designed for Python 3.8.2

Make sure to perform 'pip install -r requirements.txt' first for all required modules in order to run this script.

Install the latest version of FireFox. If the script still doesn't open a web broswer, modified the script by changing the directory location to point to firefox.exe.

Run in this directory "Start_The_Block.py" to start the program.