Script was designed for Python 3.8.2

Make sure to perform 'pip install -r requirements.txt' first for all required modules in order to run this script.

Run in this directory "Start_The_Block.py" to start the program.